<?php
/*
Template Name: Feedback Template
*/
get_header();
include('class.phpmailer.php');
?>
<script>
function ValidateForm(){
	    var emailRegex = /^[A-Za-z0-9._]*$/;
	    email = document.form.email.value,
		message = document.form.message.value;
   if (email == "" )
	{
		document.form.email.focus();
		document.getElementById("errorBox").innerHTML = "Enter the email";
		return false;
	 }else if(!emailRegex.test(email)){
		document.form.email.focus();
		document.getElementById("errorBox").innerHTML = "Enter the valid email, no need to include @iiml.ac.in";
		return false;
	 }
   if(message == "")
	 {
		 document.form.message.focus();
		 document.getElementById("errorBox").innerHTML = "Enter the message";
		 return false;
	 }  
}
</script>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<main id="kt-primary" style="padding: 0px;">
				<div id="kt-content" class="clearfix">
                	<header class="entry-header clearfix">
						<h1 class="entry-title"  itemprop="name"><?php the_title(); ?></h1>
					</header>
                    <section class="kt-entry-content clearfix">
						<div></div>
<span class="err" id="errorBox">					
<?php 
if(isset($_POST['send'])&&isset($_POST['email'])&&isset($_POST['message'])){
        
		$email=$_POST['email']."@iiml.ac.in";
		$mail = new PHPMailer();
		//From email address and name
		$mail->From = "test@infoseeksoftwaresystems.com";
		$mail->FromName = "InYourReach";
		
		//To address and name
		$mail->addAddress("testinguser500@gmail.com", "Testing User");
		$mail->addAddress("nidhi@inyourreach.in","Nidhi Verma"); //Recipient name is optional
		
		//Address to which recipient will reply
		$mail->addReplyTo($email, "Reply");
		
		//CC and BCC
		$mail->addCC("sangita@inyourreach.in");
		$mail->addBCC("yamini@inyourreach.in");
		
		//Send HTML or Plain Text email
		$mail->isHTML(true);
		
		$mail->Subject = "Feedback From ".$email;
		$mail->Body = $_POST['message'];
		
		if(!$mail->send()) 
		{
			echo "Mailer Error: " . $mail->ErrorInfo;
		} 
		else 
		{
			echo "Message has been sent successfully";
		}
}
?>
</span>	
<form name="form" id="form" action="" method="post" onSubmit="return ValidateForm()">
<p>Your Email (*)<br>
<span class="wpcf7-form-control-wrap text-email">
<input type="text" name="email" value="" size="40" class=""></span>@iiml.ac.in
</p>
<p>Your Message<br>
<span class="wpcf7-form-control-wrap your-message">
<textarea name="message" cols="40" rows="10" maxlength="250" class=""></textarea></span></p>
<p><input type="submit" value="Send" class="" name="send">
</p>
</form>
                       		
                            
						<!--</div>-->
        			</section>
                </div>
			</main>
		</div>
	</div>
</div>
<?php
get_footer();
?>