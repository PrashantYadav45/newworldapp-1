<?php include('class.phpmailer.php');?>
<html>
<head>
<title>Mail Through SMTP</title>
</head>
<body>
<form action="#" method="post">
<br/><br/><br/>
<div align="center">
<input type="email" name="email" value="testinguser500@gmail.com">
<input type="submit" name="send">
</div>
</form>
<?php  
    if(isset($_POST['send'])&&isset($_POST['email'])){
        
		$email=$_POST['email'];
		$mail = new PHPMailer();
		//From email address and name
		$mail->From = "test@infoseeksoftwaresystems.com";
		$mail->FromName = "InYourReach";
		
		//To address and name
		$mail->addAddress("testinguser500@gmail.com", "Testing User");
		//$mail->addAddress("nidhi@inyourreach.in","Nidhi Verma"); //Recipient name is optional
		
		//Address to which recipient will reply
		$mail->addReplyTo($email, "Reply");
		
		//CC and BCC
		//$mail->addCC("sangita@inyourreach.in");
		//$mail->addBCC("yamini@inyourreach.in");
		
		//Send HTML or Plain Text email
		$mail->isHTML(true);
		
		$mail->Subject = "Testing Mail From ".$email;
		$mail->Body = 'Testing Email';
		
		if(!$mail->send()) 
		{
			echo "Mailer Error: " . $mail->ErrorInfo;
		} 
		else 
		{
			echo "Message has been sent successfully";
		}
}
?>
</body>
</html>